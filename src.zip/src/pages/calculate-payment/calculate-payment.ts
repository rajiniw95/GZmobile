import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-calculate-payment',
  templateUrl: 'calculate-payment.html'
})
export class CalculatePaymentPage {

  constructor(public navCtrl: NavController) {
  }
  
}
