import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-upload-deposit-slip',
  templateUrl: 'upload-deposit-slip.html'
})
export class UploadDepositSlipPage {

  constructor(public navCtrl: NavController) {
  }
  
}
